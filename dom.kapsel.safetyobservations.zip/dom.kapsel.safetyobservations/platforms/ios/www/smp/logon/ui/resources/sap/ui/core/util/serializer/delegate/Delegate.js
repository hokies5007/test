/*
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.core.util.serializer.delegate.Delegate");jQuery.sap.require("sap.ui.base.EventProvider");sap.ui.base.EventProvider.extend("sap.ui.core.util.serializer.delegate.Delegate",{constructor:function(){sap.ui.base.EventProvider.apply(this)}});
sap.ui.core.util.serializer.delegate.Delegate.prototype.start=function(c,a,i){return""};
sap.ui.core.util.serializer.delegate.Delegate.prototype.middle=function(c,a,i){return""};
sap.ui.core.util.serializer.delegate.Delegate.prototype.end=function(c,a,i){return""};
sap.ui.core.util.serializer.delegate.Delegate.prototype.startAggregation=function(c,a){return""};
sap.ui.core.util.serializer.delegate.Delegate.prototype.endAggregation=function(c,a){return""};
