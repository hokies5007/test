/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.core.SeparatorItem");jQuery.sap.require("sap.ui.core.library");jQuery.sap.require("sap.ui.core.Item");sap.ui.core.Item.extend("sap.ui.core.SeparatorItem",{metadata:{library:"sap.ui.core"}});
