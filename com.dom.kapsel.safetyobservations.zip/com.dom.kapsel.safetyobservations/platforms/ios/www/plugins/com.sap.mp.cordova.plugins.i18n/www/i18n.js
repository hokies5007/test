cordova.define("com.sap.mp.cordova.plugins.i18n.i18n", function(require, exports, module) { // 3.0.3
var defaultLocale = "en";

function getUserLocale() {
    var locale;

    // Workaround for Android 2.3.x
    if (navigator && navigator.userAgent && (androidLang = navigator.userAgent.match(/android.*\W(\w\w)-(\w\w)\W/i))) {
        locale = androidLang[1];
    } else {
        locale = navigator.userLanguage || navigator.language;
    }

    locale = locale.replace('-', '_');

    return locale.toLowerCase();
}

function getFilePath(locale, path, name) {
    if (locale) {
        return path + "/" + name + "_" + locale + ".json";
    } else {
        return path + "/" + name + ".json";
    }
}

function loadMessages(i18n) {
    // Messages are loaded in the following order language_territory, language, and default
    // eg.  messages_en_us.json, messages_en.json, messages_{default}.json
    var userLocale = getUserLocale(),
        lang = userLocale.split('_')[0],
        locales = [userLocale];

    i18n.messages = [];

    // Could be en_US and en
    if (userLocale !== lang) {
        locales.push(lang);
    }

	if (!(defaultLocale in locales)) {
    	locales.push(defaultLocale); // Default
	}
	
    for (var i = 0; i < locales.length; i++) {
        var locale = locales[i];
        var filePath = getFilePath(locale, i18n.path, i18n.name);

        var xhr = new XMLHttpRequest();
        xhr.open("GET", filePath, false);
        xhr.send();

        if (xhr.responseText && xhr.responseText.length > 0) {
            i18n.messages[locale] = JSON.parse(xhr.responseText);
        }
    }
}

var i18n = function (options) {
    this.name = options.name ? options.name : "messages";
    this.path = options.path;
    this.messages = null;
}

i18n.prototype.get = function (key) {
    if (!this.messages) {
        loadMessages(this);
    }

    for (var locale in this.messages) {
        if (this.messages[locale][key]) {
            return this.messages[locale][key];
        }
    }
}

module.exports.load = function (options) {
    return new i18n(options);
}
});
