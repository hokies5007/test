/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.VBoxRenderer");jQuery.sap.require("sap.m.FlexBoxRenderer");sap.m.VBoxRenderer={};
sap.m.VBoxRenderer.render=function(r,c){sap.m.FlexBoxRenderer.render.apply(this,[r,c])};
