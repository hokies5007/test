/*
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.app.MockServer");jQuery.sap.require("sap.ui.core.util.MockServer");(function(){sap.ui.app.MockServer=sap.ui.core.util.MockServer})();
