/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.core.ListItem");jQuery.sap.require("sap.ui.core.library");jQuery.sap.require("sap.ui.core.Item");sap.ui.core.Item.extend("sap.ui.core.ListItem",{metadata:{library:"sap.ui.core",properties:{"icon":{type:"string",group:"Appearance",defaultValue:null},"additionalText":{type:"string",group:"Data",defaultValue:null}}}});
